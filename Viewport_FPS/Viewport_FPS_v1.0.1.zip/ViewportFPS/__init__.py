# SPDX-License-Identifier: GPL-2.0-or-later
#
# Viewport FPS
# Copyright (C) 2025 Pazelock
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.



bl_info = {
    "name": "Viewport FPS",
    "author": "Pazelock",
    "version": (1, 0, 1),
    "blender": (4, 2, 0),
    "category": "3D View",
    "website": "https://extensions.blender.org/add-ons/viewport-fps",
    "tracker_url": "https://github.com/pazelock/viewport-fps/issues",
    "doc_url": "https://github.com/Pazelock/Viewport-FPS/blob/main/docs/GUIDE.md",
}


import bpy
import blf
import time

_draw_handler = None
_last_time = time.time()
_fps = 0
_cached_fps = 0.0
_frame_counter = 0
_accum_delta = 0.0

# Preferences

class AlwaysFPSPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    show_label: bpy.props.BoolProperty(name='Show "FPS:" Label', default=True)
    show_decimals: bpy.props.BoolProperty(name='Show Decimals', default=False)
    warn_fps: bpy.props.FloatProperty(name="Warning FPS", default=30.0, min=1.0, max=240.0)
    refresh_frames: bpy.props.IntProperty(
        name="Refresh Every N Frames",
        description="Update displayed FPS every N viewport redraws",
        default=10,
        min=1,
        max=600
    )
    font_size: bpy.props.IntProperty(name="Font Size", default=10, min=6, max=64)
    pos_x: bpy.props.IntProperty(name="Position X", default=750, min=0, max=10000)
    pos_y: bpy.props.IntProperty(name="Position Y", default=28, min=0, max=10000)
    pivot: bpy.props.EnumProperty(
        name="Pivot",
        description="Select the corner for position reference",
        items=[
            ('BL', "Bottom Left", ""),
            ('BR', "Bottom Right", ""),
            ('TL', "Top Left", ""),
            ('TR', "Top Right", "")
        ],
        default='TL'
    )
    normal_color: bpy.props.FloatVectorProperty(
        name="Normal FPS Color", subtype='COLOR', size=4,
        min=0.0, max=1.0, default=(0.5, 1.0, 0.5, 0.75)
    )
    warning_color: bpy.props.FloatVectorProperty(
        name="Warning FPS Color", subtype='COLOR', size=4,
        min=0.0, max=1.0, default=(1.0, 0.2, 0.2, 1.0)
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Always Show Viewport FPS")
        layout.separator()
        layout.prop(self, "show_label")
        layout.prop(self, "show_decimals")
        layout.prop(self, "warn_fps")
        layout.prop(self, "refresh_frames")
        layout.prop(self, "font_size")
        col = layout.column(align=True)
        col.label(text="Position")
        row = col.row(align=True)
        row.prop(self, "pivot", expand=True)
        col.prop(self, "pos_x")
        col.prop(self, "pos_y")
        col = layout.column(align=True)
        col.label(text="Colors")
        col.prop(self, "normal_color")
        col.prop(self, "warning_color")

# Draw callback

def fps_draw_callback():
    global _fps, _cached_fps, _frame_counter, _last_time, _accum_delta

    prefs = bpy.context.preferences.addons[__package__].preferences

    # Measure delta time
    now = time.time()
    delta = now - _last_time
    _last_time = now
    _fps = 1.0 / delta if delta > 0 else 0.0

    # Accumulate delta for averaging
    _accum_delta += delta
    _frame_counter += 1

    if _frame_counter >= prefs.refresh_frames:
        avg_delta = _accum_delta / _frame_counter
        _cached_fps = 1.0 / avg_delta if avg_delta > 0 else 0.0
        _accum_delta = 0.0
        _frame_counter = 0

    # Choose color
    color = prefs.warning_color if _cached_fps < prefs.warn_fps else prefs.normal_color
    blf.color(0, *color)

    # Build text
    text = f"{_cached_fps:.1f}" if prefs.show_decimals else f"{int(round(_cached_fps))}"
    if prefs.show_label:
        text = f"FPS: {text}"

    # Draw for each 3D View area
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            width, height = area.width, area.height
            text_width, text_height = blf.dimensions(0, text)

            x, y = prefs.pos_x, prefs.pos_y
            if prefs.pivot == 'BL':
                draw_x = 0 + x
                draw_y = 0 + y
            elif prefs.pivot == 'BR':
                draw_x = width - x - text_width
                draw_y = 0 + y
            elif prefs.pivot == 'TL':
                draw_x = 0 + x
                draw_y = height - y - text_height
            elif prefs.pivot == 'TR':
                draw_x = width - x - text_width
                draw_y = height - y - text_height

            blf.position(0, draw_x, draw_y, 0)
            blf.size(0, prefs.font_size)
            blf.draw(0, text)

# Timer to force redraw

def fps_timer():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    return 0.01

# Enable / Disable

def enable_fps_overlay():
    global _draw_handler
    if _draw_handler is None:
        _draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            fps_draw_callback, (), 'WINDOW', 'POST_PIXEL'
        )
    if not bpy.app.timers.is_registered(fps_timer):
        bpy.app.timers.register(fps_timer, persistent=True)

def disable_fps_overlay():
    global _draw_handler
    if _draw_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        _draw_handler = None

# Reg

def register():
    bpy.utils.register_class(AlwaysFPSPreferences)
    enable_fps_overlay()

def unregister():
    disable_fps_overlay()
    bpy.utils.unregister_class(AlwaysFPSPreferences)
